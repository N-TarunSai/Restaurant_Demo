import { useDispatch, useSelector } from 'react-redux';
import { setQuery, setVeg } from '../slices/filtersSlice';

/**
 * Filters Component
 * Renders search input and vegetarian/non-vegetarian filters.
 */
export default function Filters() {
  const dispatch = useDispatch();

  // Redux state
  const query = useSelector(state => state.filters.query);
  const veg = useSelector(state => state.filters.veg);

  // Toggle checkbox filter
  const handleVegToggle = (type) => {
    dispatch(setVeg(veg === type ? 'all' : type));
  };

  return (
    <div className="search-row">
      {/* Search Input */}
      <input
        type="text"
        placeholder="Search dishes..."
        value={query}
        onChange={e => dispatch(setQuery(e.target.value))}
      />

      {/* Veg Filter */}
      <label className="row" style={{ gap: 8 }}>
        <input
          type="checkbox"
          checked={veg === 'veg'}
          onChange={() => handleVegToggle('veg')}
        />
        Veg only
      </label>

      {/* Non-Veg Filter */}
      <label className="row" style={{ gap: 8 }}>
        <input
          type="checkbox"
          checked={veg === 'non-veg'}
          onChange={() => handleVegToggle('non-veg')}
        />
        Non‑Veg only
      </label>
    </div>
  );
}
