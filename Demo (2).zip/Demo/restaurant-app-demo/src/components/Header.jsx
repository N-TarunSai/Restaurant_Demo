import { Link, NavLink } from "react-router-dom";
import "../styles/header.css";

export default function Header() {
  return (
    <header className="header">
      <div className="container wrap">
        <center>
        <div>
          <Link className="brand" to="/">
            ABC Multi Cuisine
            <br />
            <div>Restaurant</div>
          </Link>
        </div>
        </center>
        <nav className="nav">
          <NavLink to="/" end>
            Menu
          </NavLink>
          <NavLink to="/book">Book a Table</NavLink>
          <Link to="/order" className="cta">
            <button>Order Online</button>
          </Link>
        </nav>
      </div>
    </header>
  );
}
