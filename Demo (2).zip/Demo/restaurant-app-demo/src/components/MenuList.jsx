import { SECTIONS } from '../data/menu';
import '../styles/menu.css';

/**
 * MenuList Component
 * Renders a list of menu items categorized by sections.
 *
 * Props:
 * - items: Array of menu items
 * - showImages: Boolean (optional) - whether to show item thumbnails
 * - controlsRenderer: Function (optional) - custom renderer for item controls (e.g., add to cart)
 */
export default function MenuList({ items, showImages = false, controlsRenderer }) {
  return (
      <section id="menu-section container">
      <h1 className="title">Menu</h1>

      {SECTIONS.map(section => {
        const sectionItems = items.filter(item => item.section === section);

        return (
          <div className="menu-block" key={section}>
            <h3>{section}</h3>
            <div>
              {sectionItems.map(item => (
                <div className="item" key={item.id}>  
                  {/* Item Details */}
                  <div className="meta">
                    {showImages && (
                      <img className="thumb" src={item.img} alt={item.name} />
                    )}

                    <div>
                      <div className="row" style={{ gap: 8 }}>
                        <span className={`dot ${item.type === 'veg' ? 'veg' : 'nonveg'}`} />
                        <strong>{item.name}</strong>
                        <span className="badge">{item.type}</span>
                      </div>

                      <div style={{ color: 'var(--muted)' }}>
                        {item.desc}
                      </div>
                    </div>
                  </div>

                  {/* Price & Controls */}
                  <div className="controls">
                    <div className="price">₹{item.price}</div>
                    {controlsRenderer?.(item)}
                  </div>

                </div>
              ))}
            </div>
          </div>
        );
      })}
    </section> 
  );
}
