
export const MENU = [
  { id: 1, name: 'Soup of the Day', section:'Starters', desc:'Chef’s choice fresh soup.', price: 199, type:'veg', img:'https://i.pinimg.com/736x/a5/56/8d/a5568d9883241fbd2fb35833e1f4c977.jpg' },
  { id: 2, name: 'Smoked Salmon Toasts', section:'Starters', desc:'Caper crème, dill, lemon.', price: 349, type:'non-veg', img:'https://i.pinimg.com/736x/f0/f6/7a/f0f67a3cdecb11b072f81c15305a849c.jpg'   },
  { id: 3, name: 'Roasted Vegetables', section:'Starters', desc:'Seasonal veggies, olive oil.', price: 249, type:'veg', img:'https://www.wellplated.com/wp-content/uploads/2021/12/What-to-do-with-roasted-vegetables.jpg' },
  { id: 4, name: 'Rosemary Chicken', section:'Main Courses', desc:'Herb jus, garlic mash.', price: 449, type:'non-veg', img:'https://littlespicejar.com/wp-content/uploads/2019/04/Easy-Lemon-Rosemary-Chicken-1.jpg' },
  { id: 5, name: 'Salmon in Black Butter', section:'Main Courses', desc:'Classic meunière.', price: 499, type:'non-veg', img:'https://www.cookingclassy.com/wp-content/uploads/2021/06/blackened-salmon-4.jpg' },
  { id: 6, name: 'Melin’s Burger', section:'Main Courses', desc:'Cheddar, house sauce.', price: 299, type:'non-veg', img:'https://b.zmtcdn.com/data/pictures/8/21034948/a368c43b900ec4dbb54030dae343aa29.jpg' },
  { id: 7, name: 'Margherita Pizza', section:'Fast Foods', desc:'Tomato, mozzarella, basil.', price: 329, type:'veg', img:'https://i.pinimg.com/236x/a2/74/1c/a2741cd8d94391ea7fdafbb266599c1a.jpg' },
  { id: 8, name: 'Masala Fries', section:'Fast Foods', desc:'Crispy masala-dusted fries.', price: 149, type:'veg', img:'https://i.pinimg.com/736x/65/3b/6d/653b6d8ab792a5765f2546210f119f1a.jpg' },
  { id: 9, name: 'Cold Coffee', section:'Beverages', desc:'Thick, creamy and chilled.', price: 129, type:'veg', img:'https://i.pinimg.com/736x/6b/0c/c3/6b0cc3ad9bbc55f64db79532f31e41e5.jpg' },
  { id:10, name: 'Lime Soda', section:'Beverages', desc:'Sweet & salted.', price: 89, type:'veg', img:'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTz7ySFUelBTa0gLURJ9Bep4aSq7bi362Wc6A&s' },
  { id: 11, name: 'Bruschetta', section:'Starters', desc:'Grilled bread, tomato, basil.', price: 229, type:'veg', img:'https://tse2.mm.bing.net/th/id/OIP.wtMm-I_bIPOBFtb70PZQlgAAAA?r=0&cb=ucfimg2ucfimg=1&rs=1&pid=ImgDetMain&o=7&rm=3' },
  { id: 12, name: 'Prawn Cocktail', section:'Starters', desc:'Chilled prawns, cocktail sauce.', price: 379, type:'non-veg', img:'https://i.pinimg.com/736x/df/0b/81/df0b815e022c55d071b107d3f2158e58--prawn-cocktail-cocktail-party.jpg' },
  { id: 13, name: 'Stuffed Mushrooms', section:'Starters', desc:'Cheese and herbs.', price: 259, type:'veg', img:'https://i.pinimg.com/originals/f8/91/08/f89108f4ca565d16f56d53a75b25a7f8.jpg' },
  { id: 14, name: 'Grilled Paneer Steak', section:'Main Courses', desc:'Spiced paneer, sautéed veg.', price: 399, type:'veg', img:'https://i.pinimg.com/originals/56/a9/40/56a94038cc65839ebc9aed676546eaf0.jpg' },
  { id: 15, name: 'Spaghetti Bolognese', section:'Main Courses', desc:'Classic meat sauce pasta.', price: 429, type:'non-veg', img:'https://tse2.mm.bing.net/th/id/OIP.Ptl2pXXRQ5QADMZrNqyFhgHaLH?r=0&cb=ucfimg2ucfimg=1&rs=1&pid=ImgDetMain&o=7&rm=3' },
  { id: 16, name: 'Chole Bhature', section:'Main Courses', desc:'Spiced chickpeas, fried bread.', price: 229, type:'veg', img:'https://i.pinimg.com/736x/eb/54/50/eb5450de8f647299d97b11e859200cb7.jpg' },
  { id: 17, name: 'Paneer Tikka Wrap', section:'Fast Foods', desc:'Spiced paneer, mint chutney.', price: 199, type:'veg', img:'https://img.freepik.com/premium-photo/paneer-tikka-wrap-isolated-white-background_1166140-11133.jpg' },
  { id: 18, name: 'Chicken Shawarma', section:'Fast Foods', desc:'Garlic mayo, pickled onions.', price: 249, type:'non-veg', img:'https://tse1.mm.bing.net/th/id/OIP.i04fFNTGePX6i50LIRpS8wAAAA?r=0&cb=ucfimg2ucfimg=1&rs=1&pid=ImgDetMain&o=7&rm=3' },
  { id: 19, name: 'Oreo Shake', section:'Beverages', desc:'Rich chocolate & crushed Oreo.', price: 159, type:'veg', img:'https://tse2.mm.bing.net/th/id/OIP.uLvvR-oYDABy-_sAWCzFGwHaLH?r=0&cb=ucfimg2ucfimg=1&rs=1&pid=ImgDetMain&o=7&rm=3' },
  { id: 20, name: 'Iced Lemon Tea', section:'Beverages', desc:'Refreshing chilled tea.', price: 99, type:'veg', img:'https://tse1.mm.bing.net/th/id/OIP.8mLlzR5Dd5ZHzPesdZDPEwHaLH?r=0&cb=ucfimg2ucfimg=1&rs=1&pid=ImgDetMain&o=7&rm=3' }
];

export const SECTIONS = ['Starters','Main Courses','Fast Foods','Beverages'];
