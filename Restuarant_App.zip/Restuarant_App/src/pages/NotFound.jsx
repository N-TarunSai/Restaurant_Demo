export default function NotFound() {
    return (
        <div className='container'>
            <h1 className='title'>Not Found</h1>
        </div>
    )
}