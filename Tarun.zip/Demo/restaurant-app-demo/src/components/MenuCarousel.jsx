// import { useEffect, useRef } from 'react'
// import { MENU } from '../data/menu'
// import '../styles/global.css'

// export default function MenuCarousel() {
//   const scrollRef = useRef(null)
//   const animationRef = useRef(null)
//   const resetTimeoutRef = useRef(null)

//   useEffect(() => {
//     const scrollContainer = scrollRef.current
//     if (!scrollContainer) return

//     const scrollStep = 0.5 // Smooth pixels per frame
//     const scrollDelay = 1000 // Delay before reset (1s)

//     let maxScrollLeft = 0

//     const scroll = () => {
//       if (scrollContainer.scrollLeft >= maxScrollLeft) {
//         // Reached end — pause then reset
//         cancelAnimationFrame(animationRef.current)
//         resetTimeoutRef.current = setTimeout(() => {
//           scrollContainer.scrollLeft = 0
//           animationRef.current = requestAnimationFrame(scroll)
//         }, scrollDelay)
//       } else {
//         scrollContainer.scrollLeft += scrollStep
//         animationRef.current = requestAnimationFrame(scroll)
//       }
//     }

//     const startScroll = () => {
//       maxScrollLeft = scrollContainer.scrollWidth - scrollContainer.clientWidth
//       animationRef.current = requestAnimationFrame(scroll)
//     }

//     const handleLoad = () => {
//       setTimeout(startScroll, 100) // Wait for DOM/images
//     }

//     if (document.readyState === 'complete') {
//       handleLoad()
//     } else {
//       window.addEventListener('load', handleLoad)
//     }

//     return () => {
//       cancelAnimationFrame(animationRef.current)
//       clearTimeout(resetTimeoutRef.current)
//       window.removeEventListener('load', handleLoad)
//     }
//   }, [])

//   return (
//     <div
//       ref={scrollRef}
//       className="horizontal-scroll-container"
//       style={{
//         display: 'flex',
//         overflowX: 'auto',
//         scrollSnapType: 'x mandatory',
//         gap: '10px',
//         padding: '10px',
//         width: '100%',
//         boxSizing: 'border-box',
//         scrollbarWidth: 'none',
//       }}
//     >
//       {MENU.map((item) => (
//         <div
//           key={item.id}
//           className="image-wrapper"
//           style={{
//             flex: '0 0 auto',
//             scrollSnapAlign: 'start',
//             width: '300px',
//             height: '200px',
//             borderRadius: '8px',
//             overflow: 'hidden',
//             boxShadow: '0 2px 8px rgba(0,0,0,0.2)',
//           }}
//         >
//           <img
//             src={item.img}
//             alt={item.name}
//             style={{
//               width: '100%',
//               height: '100%',
//               objectFit: 'cover',
//               display: 'block',
//               borderRadius: '8px',
//             }}
//           />
//         </div>
//       ))}
//     </div>
//   )
// }

// import { MENU } from '../data/menu'
// import '../styles/global.css'

// export default function MenuCarousel() {
//   return (
//     <div className="static-carousel-container">
//       {MENU.map((item) => (
//         <div key={item.id} className="static-carousel-slide">
//           <img src={item.img} alt={item.name} />
//         </div>
//       ))}
//     </div>
//   )
// }

// import { useState } from 'react'
// import { MENU } from '../data/menu'
// import '../styles/global.css'

// export default function MenuCarousel() {
//   const [index, setIndex] = useState(0)
//   const visibleCount = 3

//   const prevSlide = () => {
//     setIndex((prev) => Math.max(prev - 1, 0))
//   }

//   const nextSlide = () => {
//     setIndex((prev) =>
//       prev + visibleCount < MENU.length ? prev + 1 : prev
//     )
//   }

//   const visibleItems = MENU.slice(index, index + visibleCount)

//   return (
//     <div className="carousel-container">
//       <button className="nav-button left" onClick={prevSlide}>
//         ‹
//       </button>

//       <div className="carousel-track">
//         {visibleItems.map((item) => (
//           <div className="carousel-slide" key={item.id}>
//             <img src={item.img} alt={item.name} />
//           </div>
//         ))}
//       </div>

//       <button className="nav-button right" onClick={nextSlide}>
//         ›
//       </button>
//     </div>
//   )
// }
//working good
// import { useEffect, useState } from 'react'
// import { MENU } from '../data/menu'
// import '../styles/global.css'

// export default function MenuCarousel() {
//   const [index, setIndex] = useState(0)
//   const visibleCount = 3

//   useEffect(() => {
//     const interval = setInterval(() => {
//       setIndex((prevIndex) =>
//         prevIndex + visibleCount >= MENU.length ? 0 : prevIndex + 1
//       )
//     }, 2000)

//     return () => clearInterval(interval)
//   }, [])

//   const visibleItems = MENU.slice(index, index + visibleCount)

//   const slidesToShow =
//     visibleItems.length < visibleCount
//       ? [...visibleItems, ...MENU.slice(0, visibleCount - visibleItems.length)]
//       : visibleItems

//   return (
//     <div className="carousel-container">
//       <div className="carousel-track">
//         {slidesToShow.map((item) => (
//           <div className="carousel-slide" key={item.id}>
//             <img src={item.img} alt={item.name} />
//           </div>
//         ))}
//       </div>
//     </div>
//   )
// }

import { useEffect, useState } from 'react'
import { MENU } from '../data/menu'
import '../styles/MenuCarousel.css'

export default function MenuCarousel() {
  const [index, setIndex] = useState(0)
  const [visibleCount, setVisibleCount] = useState(3)

  useEffect(() => {
    const updateVisibleCount = () => {
      const width = window.innerWidth
      if (width < 640) {
        setVisibleCount(1)
      } else if (width < 1024) {
        setVisibleCount(2)
      } else {
        setVisibleCount(3)
      }
    }

    updateVisibleCount()
    window.addEventListener('resize', updateVisibleCount)
    return () => window.removeEventListener('resize', updateVisibleCount)
  }, [])

  useEffect(() => {
    const interval = setInterval(() => {
      setIndex((prevIndex) =>
        prevIndex + visibleCount >= MENU.length ? 0 : prevIndex + 1
      )
    }, 2000)

    return () => clearInterval(interval)
  }, [visibleCount])

  const visibleItems = MENU.slice(index, index + visibleCount)

  // Wrap around at end if not enough items
  const slidesToShow =
    visibleItems.length < visibleCount
      ? [...visibleItems, ...MENU.slice(0, visibleCount - visibleItems.length)]
      : visibleItems

  return (
    <div className="carousel-container">
      <div className="carousel-track">
        {slidesToShow.map((item) => (
          <div className="carousel-slide" key={item.id}>
            <img src={item.img} alt={item.name} />
          </div>
        ))}
      </div>
    </div>
  )
}

