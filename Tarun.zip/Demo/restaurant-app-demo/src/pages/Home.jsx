
import MenuList from '../components/MenuList'
import MenuCarousel from '../components/MenuCarousel'
import { MENU } from '../data/menu'
import '../styles/menu.css'

export default function Home(){
  return (
    <>
      {/* <div className="hero">
        <div className="overlay">
          <div className="container">
            <h1 className="title">Menu</h1>
            <p style={{textAlign:'center',color:'var(--muted)'}}>Explore our hand‑picked dishes.</p>
          </div>
        </div>
      </div> */}
      <MenuCarousel />
      <center> 
        <div id="MENU">
        <MenuList items={MENU} />
        </div> 
      </center>
      
    </>
  )
}
