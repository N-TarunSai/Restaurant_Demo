
export default function Filters({query,setQuery,veg,setVeg}){
  return (
    <div className="search-row">
      <input
        placeholder="Search dishes..."
        value={query}
        onChange={e=>setQuery(e.target.value)}
      />
      <label className="row" style={{gap:8}}>
        <input type="checkbox" checked={veg==='veg'} onChange={e=>setVeg(veg==='veg'? 'all':'veg')}/>
        Veg only
      </label>
      <label className="row" style={{gap:8}}>
        <input type="checkbox" checked={veg==='non-veg'} onChange={e=>setVeg(veg==='non-veg'? 'all':'non-veg')}/>
        Non‑Veg only
      </label>
    </div>
  )
}
