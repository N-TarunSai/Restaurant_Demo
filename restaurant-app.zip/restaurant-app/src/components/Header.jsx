
import { Link, NavLink } from 'react-router-dom'
import '../styles/header.css'

export default function Header(){
  return (
    <header className="header">
      <div className="container wrap">
        <div>
          <Link className="brand" to="/">ABC Multi Cuisine<br/>Restaurant</Link>
        </div>
        <nav className="nav">
          <NavLink to="/" end>Menu</NavLink>
          <NavLink to="/book">Book a Table</NavLink>
          {/* <NavLink to="/contact" onClick={(e)=>e.preventDefault()}>Contact</NavLink> */}
          {/* <Link className="cta"><button>Order Online</button></Link> */}
          <Link to="/order" className="cta"><button>Order Online</button></Link>
        </nav>
      </div>
    </header>
  )
}
