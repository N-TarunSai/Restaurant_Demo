
import { SECTIONS } from '../data/menu'
import '../styles/menu.css'

export default function MenuList({items,showImages=false,controlsRenderer}){
  return (
    <section className="menu-section container">
      <h1 className="title">Menu</h1>
      {SECTIONS.map(sec => (
        <div className="menu-block" key={sec}>
          <h3>{sec}</h3>
          <div>
            {items.filter(i=>i.section===sec).map(item=>(
              <div className="item" key={item.id}>
                <div className="meta">
                  {showImages && <img className="thumb" src={item.img} alt={item.name}/>}
                  <div>
                    <div className="row" style={{gap:8}}>
                      <span className={"dot "+(item.type==='veg'?'veg':'nonveg')}></span>
                      <strong>{item.name}</strong>
                      <span className="badge">{item.type}</span>
                    </div>
                    <div style={{color:'var(--muted)'}}>{item.desc}</div>
                  </div>
                </div>
                <div className="controls">
                  <div className="price">₹{item.price}</div>
                  {controlsRenderer && controlsRenderer(item)}
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </section>
  )
}
