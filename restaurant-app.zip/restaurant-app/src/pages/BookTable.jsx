
import { useMemo, useState } from 'react'
import '../styles/book.css'

function Modal({open,onClose,title,children}){
  if(!open) return null
  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={e=>e.stopPropagation()}>
        <header><h3>{title}</h3><button onClick={onClose}>✕</button></header>
        <div className="content">{children}</div>
        <footer><button onClick={onClose}>Close</button></footer>
      </div>
    </div>
  )
}

export default function BookTable(){
  const [date,setDate] = useState(()=> new Date().toISOString().slice(0,10))
  const [time,setTime] = useState('19:00')
  const [size,setSize] = useState(2)
  const [open,setOpen] = useState(false)
  const tableNo = useMemo(()=> Math.floor(Math.random()*20)+1, [open])

  const times = Array.from({length:12},(_,i)=>{
    const h = 11 + i
    return `${String(h).padStart(2,'0')}:00`
  })

  return (
    <section className="book-section">
  <div className="overlay">
    <h1 className="title">Book a Table</h1>
    <p className="info">
      Please be on the selected time slot to make sure the table is not allotted to others
    </p>
    <div className="form-row">
      <div>
        <label>Date</label>
        <input type="date" value={date} onChange={e=>setDate(e.target.value)} />
      </div>
      <div>
        <label>Time</label>
        <select value={time} onChange={e=>setTime(e.target.value)}>
          {times.map(t=>(<option key={t} value={t}>{t}</option>))}
        </select>
      </div>
      <div>
        <label>Party size</label>
        <select value={size} onChange={e=>setSize(Number(e.target.value))}>
          {Array.from({length:9},(_,i)=>i+2).map(n=>(<option key={n} value={n}>{n}</option>))}
        </select>
      </div>
      <div style={{alignSelf:'end'}}>
        <button onClick={()=>setOpen(true)}>Book Now</button>
      </div>
    </div>
  </div>

  <img
    className="Image"
    src="https://static.wixstatic.com/media/0b340f_78ad19e599d642a28de7ce823686cbc6~mv2.jpg/v1/fill/w_1785,h_911,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/0b340f_78ad19e599d642a28de7ce823686cbc6~mv2.jpg"
    alt="Image"
  />

  <Modal open={open} onClose={()=>setOpen(false)} title="Reservation Successful">
    <div className="success">
      <p>Your table has been reserved.</p>
      <ul>
        <li><strong>Date:</strong> {date}</li>
        <li><strong>Time:</strong> {time}</li>
        <li><strong>Party size:</strong> {size}</li>
        <li><strong>Allotted Table No:</strong> {tableNo}</li>
      </ul>
    </div>
  </Modal>
</section>
  )
}
