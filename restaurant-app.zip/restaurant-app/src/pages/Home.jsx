
import MenuList from '../components/MenuList'
import { MENU } from '../data/menu'
import '../styles/menu.css'

export default function Home(){
  return (
    <>
      <div className="hero">
        <div className="overlay">
          <div className="container">
            <h1 className="title">Menu</h1>
            <p style={{textAlign:'center',color:'var(--muted)'}}>Explore our hand‑picked dishes.</p>
          </div>
        </div>
      </div>
      <MenuList items={MENU} />
    </>
  )
}
