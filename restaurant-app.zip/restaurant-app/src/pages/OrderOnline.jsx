
import { useMemo, useState } from 'react'
import MenuList from '../components/MenuList'
import QuantityStepper from '../components/QuantityStepper'
import Filters from '../components/Filters'
import { MENU } from '../data/menu'

function Modal({open,onClose,title,children}){
  if(!open) return null
  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={e=>e.stopPropagation()}>
        <header><h3>{title}</h3><button onClick={onClose}>✕</button></header>
        <div className="content">{children}</div>
        <footer><button onClick={onClose}>Close</button></footer>
      </div>
    </div>
  )
}

export default function OrderOnline(){
  const [query,setQuery] = useState('')
  const [veg,setVeg] = useState('all') // 'veg' | 'non-veg' | 'all'
  const [cart,setCart] = useState({}) // id -> qty
  const [open,setOpen] = useState(false)

  const filtered = useMemo(()=>{
    return MENU.filter(i=>{
      const okType = veg==='all' ? true : i.type===veg
      const okQuery = (i.name+' '+i.desc).toLowerCase().includes(query.toLowerCase())
      return okType && okQuery
    })
  },[veg,query])

  const total = Object.entries(cart).reduce((sum,[id,qty])=>{
    const item = MENU.find(i=>i.id===Number(id))
    return sum + (item? item.price*qty : 0)
  },0)

  const orderItems = Object.entries(cart).map(([id,qty])=>{
    const item = MENU.find(i=>i.id===Number(id))
    return { ...item, qty }
  })

  return (
    <section className="container">
      <h1 className="title">Order Online</h1>
      <Filters query={query} setQuery={setQuery} veg={veg} setVeg={setVeg} />
      <MenuList
        items={filtered}
        showImages
        controlsRenderer={(item)=>{
          const qty = cart[item.id] || 0
          return (
            <div>
              <button onClick={()=>setCart(c=>({...c,[item.id]: (c[item.id]||0)+1}))}>Add Item</button>
              {qty>0 && <div style={{marginTop:8}}>
                <QuantityStepper value={qty} onChange={(v)=>setCart(c=>{
                  const next={...c}; if(v<=0) delete next[item.id]; else next[item.id]=v; return next;
                })}/>
              </div>}
            </div>
          )
        }}
      />

      {Object.keys(cart).length>0 && (
        <div className="place-order">
          <button onClick={()=>setOpen(true)}>Place Order • ₹{total}</button>
        </div>
      )}

      <Modal open={open} onClose={()=>{ setOpen(false); window.location.href='/'}} title="Order Placed Successfully">
        <div>
          <h3>Summary</h3>
          <ul className="plain">
            {orderItems.map(it=>(
              <li key={it.id} className="row" style={{justifyContent:'space-between'}}>
                <span>{it.name} × {it.qty}</span>
                <span>₹{it.price*it.qty}</span>
              </li>
            ))}
          </ul>
          <hr className="divider"/>
          <div className="row" style={{justifyContent:'space-between'}}>
            <strong>Total</strong><strong>₹{total}</strong>
          </div>
        </div>
      </Modal>
    </section>
  )
}
